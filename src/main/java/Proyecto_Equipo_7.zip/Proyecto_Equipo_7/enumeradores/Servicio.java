package Proyecto_Equipo_7.enumeradores;

public enum Servicio {

    PLOMERO,
    GASISTA,
    ELECTRISISTA

}
