package Proyecto_Equipo_7.enumeradores;

public enum Rol {

    USER,
    ADMIN,
    PROVEEDOR,
    GUEST
}
