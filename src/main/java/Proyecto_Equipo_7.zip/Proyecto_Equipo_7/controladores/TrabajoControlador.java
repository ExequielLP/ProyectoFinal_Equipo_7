package Proyecto_Equipo_7.controladores;

public class TrabajoControlador {

}
