package Proyecto_Equipo_7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChacrasDeCoriaEnMendozaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChacrasDeCoriaEnMendozaApplication.class, args);
	}

}
