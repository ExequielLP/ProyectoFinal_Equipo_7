package Proyecto_Equipo_7.excepciones;

public class MiException extends Exception{

    public MiException(String msg) {
        super(msg);
    }
}
