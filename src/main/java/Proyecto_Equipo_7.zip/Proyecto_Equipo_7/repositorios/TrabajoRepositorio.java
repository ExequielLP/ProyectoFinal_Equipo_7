package Proyecto_Equipo_7.repositorios;


import Proyecto_Equipo_7.entidades.Trabajo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrabajoRepositorio extends JpaRepository<Trabajo, String>{

    
    
}
